const fs = require('fs');
const path = require('path');

const unitsDir = path.join(__dirname, '../js/data/units');

let totalWords = 0;
const wordMap = new Map();

// We will read units 1 to 10
for (let u = 1; u <= 10; u++) {
  const unitFile = `unit${u}.js`;
  const unitPath = path.join(unitsDir, unitFile);
  
  if (!fs.existsSync(unitPath)) continue;
  
  // Check if a subdirectory for this unit exists (new modular structure)
  const unitSubDir = path.join(unitsDir, `unit${u}`);
  
  if (fs.existsSync(unitSubDir) && fs.lstatSync(unitSubDir).isDirectory()) {
    console.log(`Unit ${u}: Modularized (Subdirectory found)`);
    // Read lessons from subdirectory
    const lessonFiles = fs.readdirSync(unitSubDir).filter(f => f.startsWith('lesson') && f.endsWith('.js'));
    
    // Sort lessons numerically
    lessonFiles.sort((a, b) => {
      const numA = parseInt(a.replace('lesson', '').replace('.js', ''));
      const numB = parseInt(b.replace('lesson', '').replace('.js', ''));
      return numA - numB;
    });
    
    lessonFiles.forEach(lFile => {
      const lPath = path.join(unitSubDir, lFile);
      const lContent = fs.readFileSync(lPath, 'utf8');
      
      try {
        const cleanJs = lContent.replace(/export\s+const\s+lesson\d+\s*=\s*/, '').trim().replace(/;$/, '');
        const lessonObj = eval(`(${cleanJs})`);
        
        const vocabCount = lessonObj.vocabulary ? lessonObj.vocabulary.length : 0;
        totalWords += vocabCount;
        console.log(`   Lesson ${lessonObj.id}: "${lessonObj.title}" has ${vocabCount} words.`);
        
        if (lessonObj.vocabulary) {
          lessonObj.vocabulary.forEach(v => {
            const wordKey = v.word.toLowerCase().trim();
            if (wordMap.has(wordKey)) {
              wordMap.get(wordKey).push({ unit: u, lesson: lessonObj.id });
            } else {
              wordMap.set(wordKey, [{ unit: u, lesson: lessonObj.id }]);
            }
          });
        }
      } catch (err) {
        console.error(`      Error parsing ${lFile}:`, err.message);
      }
    });
    
  } else {
    // Old flat structure
    console.log(`Unit ${u}: Flat (Main file parsing)`);
    const content = fs.readFileSync(unitPath, 'utf8');
    try {
      const jsContent = content.replace(/export\s+const\s+unit\d+\s*=\s*/, '');
      const cleanJs = jsContent.trim().replace(/;$/, '');
      const unitObj = eval(`(${cleanJs})`);
      
      unitObj.lessons.forEach(lesson => {
        const vocabCount = lesson.vocabulary ? lesson.vocabulary.length : 0;
        totalWords += vocabCount;
        console.log(`   Lesson ${lesson.id}: "${lesson.title}" has ${vocabCount} words.`);
        
        if (lesson.vocabulary) {
          lesson.vocabulary.forEach(v => {
            const wordKey = v.word.toLowerCase().trim();
            if (wordMap.has(wordKey)) {
              wordMap.get(wordKey).push({ unit: u, lesson: lesson.id });
            } else {
              wordMap.set(wordKey, [{ unit: u, lesson: lesson.id }]);
            }
          });
        }
      });
    } catch (err) {
      console.error(`   Error parsing flat ${unitFile}:`, err.message);
    }
  }
}

console.log(`\nTotal Vocabulary Entries across all units: ${totalWords}`);
console.log(`Total Unique Words: ${wordMap.size}`);

// Print duplicates
console.log(`\nDuplicate words check (top 15 duplicates):`);
let dupCount = 0;
for (const [word, occurrences] of wordMap.entries()) {
  if (occurrences.length > 1) {
    dupCount++;
    if (dupCount <= 15) {
      console.log(`   "${word}" appears ${occurrences.length} times in:`, occurrences.map(o => `U${o.unit}L${o.lesson}`).join(', '));
    }
  }
}
console.log(`Total duplicate words: ${dupCount}`);
