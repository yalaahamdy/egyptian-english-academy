const fs = require('fs');
const path = require('path');
const vm = require('vm');

const unitsDir = path.join(__dirname, '..', 'js', 'data', 'units');

for (let u = 1; u <= 10; u++) {
  const unitFile = `unit${u}.js`;
  const filePath = path.join(unitsDir, unitFile);
  if (!fs.existsSync(filePath)) {
    console.log(`Skipping missing file: ${unitFile}`);
    continue;
  }

  console.log(`Processing ${unitFile}...`);
  const unitVar = `unit${u}`;
  let unitObj;
  try {
    unitObj = parseUnitFile(filePath, unitVar);
  } catch (err) {
    console.error(`Error parsing ${unitFile}:`, err);
    continue;
  }

  // Iterate over lessons
  unitObj.lessons.forEach(lesson => {
    const vocab = lesson.vocabulary || [];
    const dialogue = lesson.dialogue || { title: "", lines: [] };
    const practice = lesson.practice || { listening: [], speaking: [], reading: { text: "", questions: [] }, writing: [] };
    const quiz = lesson.quiz || [];

    // Ensure we have arrays
    if (!practice.listening) practice.listening = [];
    if (!practice.speaking) practice.speaking = [];
    if (!practice.reading) practice.reading = { text: "", questions: [] };
    if (!practice.reading.questions) practice.reading.questions = [];
    if (!practice.writing) practice.writing = [];

    // --- 1. DOUBLE LISTENING (target size 6) ---
    const listLen = practice.listening.length;
    if (listLen < 6 && vocab.length >= 6) {
      // Add questions based on words at index 3, 4, 5
      for (let i = listLen; i < 6; i++) {
        const v = vocab[i % vocab.length];
        // Select some incorrect options from other words
        const wrongOpts = vocab.filter(w => w.word !== v.word).map(w => w.word);
        const shuffledOpts = [v.word, wrongOpts[0] || "school", wrongOpts[1] || "hospital"].sort(() => Math.random() - 0.5);
        practice.listening.push({
          text: v.example || `I know the word ${v.word}.`,
          options: shuffledOpts,
          answer: v.word,
          hint: v.translation || "كلمة الدرس"
        });
      }
    }

    // --- 2. DOUBLE SPEAKING (target size 6) ---
    const speakLen = practice.speaking.length;
    if (speakLen < 6 && vocab.length >= 6) {
      // Add examples from words at index 6, 7, 8
      for (let i = speakLen; i < 6; i++) {
        const v = vocab[i % vocab.length];
        practice.speaking.push({
          text: v.example ? v.example.replace(/[.,?!]/g, "") : `I can say ${v.word}`,
          translation: v.exampleTranslation || v.translation
        });
      }
    }

    // --- 3. DOUBLE READING QUESTIONS (target size 6) ---
    const readLen = practice.reading.questions.length;
    if (readLen < 6 && vocab.length >= 6) {
      for (let i = readLen; i < 6; i++) {
        const v = vocab[i % vocab.length];
        // Ask a question about vocabulary translation
        const wrongOpts = vocab.filter(w => w.translation !== v.translation).map(w => w.translation);
        const shuffledOpts = [v.translation, wrongOpts[0] || "مدرسة", wrongOpts[1] || "مستشفى"].sort(() => Math.random() - 0.5);
        practice.reading.questions.push({
          q: `What is the Arabic translation of the word '${v.word}'?`,
          options: shuffledOpts,
          answer: v.translation,
          explanation: `كلمة '${v.word}' تعني بالإنجليزية '${v.translation}'.`
        });
      }
    }

    // --- 4. DOUBLE WRITING (target size 6) ---
    const writeLen = practice.writing.length;
    if (writeLen < 6 && vocab.length >= 6) {
      for (let i = writeLen; i < 6; i++) {
        const v = vocab[i % vocab.length];
        if (i % 2 === 0) {
          // Scramble writing exercise based on example
          const rawExample = v.example || `I see the ${v.word}.`;
          const cleanWords = rawExample.replace(/[.,?!]/g, "").split(/\s+/).filter(Boolean);
          // Scrambled array with slashes
          const scrambledStr = [...cleanWords].sort(() => Math.random() - 0.5).join(" / ");
          practice.writing.push({
            prompt: `رتب الكلمات لتكوين جملة صحيحة: (${v.exampleTranslation || v.translation})`,
            words: [scrambledStr],
            correct: cleanWords
          });
        } else {
          // Fill in the blank exercise
          const rawExample = v.example || `I see the ${v.word}.`;
          const cleanWords = rawExample.replace(/[.,?!]/g, "").split(/\s+/).filter(Boolean);
          const wordToBlank = v.word;
          // Replace word in example with ___
          // Find case-insensitive match
          const index = cleanWords.findIndex(w => w.toLowerCase() === wordToBlank.toLowerCase());
          if (index !== -1) {
            cleanWords[index] = "___";
            const sentenceWithBlank = cleanWords.join(" ");
            const wrongOpts = vocab.filter(w => w.word !== v.word).map(w => w.word);
            practice.writing.push({
              prompt: `أكمل الفراغ: ${v.exampleTranslation || v.translation} : ${sentenceWithBlank}`,
              placeholder: `${v.word} / ${wrongOpts[0] || 'school'} / ${wrongOpts[1] || 'hospital'}`,
              answer: v.word
            });
          } else {
            // Fallback scramble
            practice.writing.push({
              prompt: `رتب الكلمات لتكوين جملة صحيحة: (${v.translation})`,
              words: [`${v.word} / clean`],
              correct: [v.word, "clean"]
            });
          }
        }
      }
    }

    // --- 5. DOUBLE QUIZ (target size 10) ---
    const quizLen = quiz.length;
    if (quizLen < 10 && vocab.length >= 10) {
      for (let i = quizLen; i < 10; i++) {
        const v = vocab[i % vocab.length];
        const wrongOpts = vocab.filter(w => w.translation !== v.translation).map(w => w.translation);
        const shuffledOpts = [v.translation, wrongOpts[0], wrongOpts[1], wrongOpts[2]].sort(() => Math.random() - 0.5);
        quiz.push({
          q: `Translate: '${v.word}'`,
          options: shuffledOpts,
          answer: v.translation,
          feedback: `ممتاز! كلمة '${v.word}' تعني '${v.translation}'.`
        });
      }
    }
  });

  // Write back to file
  const updatedContent = formatUnitFile(unitVar, unitObj);
  fs.writeFileSync(filePath, updatedContent, 'utf8');
  console.log(`Successfully updated ${unitFile}`);
}

function parseUnitFile(filePath, unitVarName) {
  const content = fs.readFileSync(filePath, 'utf8');
  // Strip export statement
  const code = content.replace(/export\s+const\s+\w+\s*=\s*/, 'var data = ') + '; data;';
  const sandbox = {};
  vm.createContext(sandbox);
  const obj = vm.runInContext(code, sandbox);
  return obj;
}

function formatUnitFile(unitVarName, obj) {
  return `export const ${unitVarName} = ${JSON.stringify(obj, null, 2)};\n`;
}
